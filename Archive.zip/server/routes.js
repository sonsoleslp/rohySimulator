import express from 'express';
import db from './db.js';

const router = express.Router();

// --- CASES ---

// GET /api/cases
router.get('/cases', (req, res) => {
    db.all("SELECT * FROM cases ORDER BY created_at DESC", [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ cases: rows });
    });
});

// POST /api/cases
router.post('/cases', (req, res) => {
    const { name, description, system_prompt, config } = req.body;
    const sql = `INSERT INTO cases (name, description, system_prompt, config) VALUES (?, ?, ?, ?)`;
    const params = [name, description, system_prompt, JSON.stringify(config)];

    db.run(sql, params, function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID, ...req.body });
    });
});

// --- SESSIONS ---

// POST /api/sessions
router.post('/sessions', (req, res) => {
    const { case_id, student_name } = req.body;
    const sql = `INSERT INTO sessions (case_id, student_name) VALUES (?, ?)`;

    db.run(sql, [case_id, student_name], function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID, case_id, student_name });
    });
});

// --- INTERACTIONS ---

// POST /api/interactions
router.post('/interactions', (req, res) => {
    const { session_id, role, content } = req.body;
    const sql = `INSERT INTO interactions (session_id, role, content) VALUES (?, ?, ?)`;

    db.run(sql, [session_id, role, content], function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID, session_id, role, content });
    });
});

// GET /api/interactions/:session_id
router.get('/interactions/:session_id', (req, res) => {
    const sql = "SELECT * FROM interactions WHERE session_id = ? ORDER BY timestamp ASC";
    db.all(sql, [req.params.session_id], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ interactions: rows });
    });
});

// --- LLM PROXY ROUTE to avoid CORS ---
router.post('/proxy/llm', async (req, res) => {
    const { targetUrl, body, headers } = req.body;

    try {
        console.log(`[Proxy] Forwarding to: ${targetUrl}`);
        const response = await fetch(targetUrl, {
            method: 'POST',
            headers: headers || { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            const errText = await response.text();
            console.error(`[Proxy] Error ${response.status}: ${errText}`);
            return res.status(response.status).json({ error: errText });
        }

        const data = await response.json();
        res.json(data);
    } catch (err) {
        console.error('[Proxy] Failure:', err);
        res.status(500).json({ error: "Proxy Request Failed", details: err.message });
    }
});

export default router;
