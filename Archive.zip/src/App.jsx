import React, { useState } from 'react';
import PatientMonitor from './components/monitor/PatientMonitor';
import PatientVisual from './components/patient/PatientVisual';
import ChatInterface from './components/chat/ChatInterface';
import ConfigPanel from './components/settings/ConfigPanel';
import { Settings, X } from 'lucide-react';

export default function App() {
   const [showConfig, setShowConfig] = useState(false);
   const [activeCase, setActiveCase] = useState(null);

   const handleLoadCase = (caseData) => {
      setActiveCase(caseData);
      setShowConfig(false);
   };

   return (
      <div className="flex h-screen w-screen bg-neutral-950 text-white overflow-hidden">

         {/* Left Column (Visual + Chat) - 35% width on large screens */}
         <div className="w-[35%] min-w-[350px] flex flex-col border-r border-neutral-800 bg-neutral-900">

            {/* Top Left: Patient Visual */}
            <div className="h-[45%] border-b border-neutral-800 relative">
               <PatientVisual
                  image="/patient_avatar.png"
                  context={activeCase?.description}
                  caseData={activeCase}
               />

               {/* Global Config Button */}
               <button
                  onClick={() => setShowConfig(true)}
                  className="absolute top-4 right-4 p-2 bg-black/50 hover:bg-black/80 text-neutral-400 hover:text-white rounded-full transition-all backdrop-blur-md z-10"
               >
                  <Settings className="w-5 h-5" />
               </button>

               {/* Case Banner */}
               {activeCase && (
                  <div className="absolute top-4 left-4 px-3 py-1 bg-blue-900/80 backdrop-blur border border-blue-500/30 rounded text-xs font-bold text-blue-100 z-10">
                     Case: {activeCase.name}
                  </div>
               )}
            </div>

            {/* Bottom Left: Chat Interface */}
            <div className="flex-1 min-h-0 relative">
               <ChatInterface activeCase={activeCase} />
            </div>

         </div>

         {/* Right Column (Monitor) - Remaining width */}
         <div className="flex-1 h-full min-w-[600px] bg-black relative">
            <PatientMonitor caseParams={activeCase?.config} />
         </div>

         {/* Global Configuration Modal */}
         {showConfig && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-8">
               <div className="bg-neutral-900 border border-neutral-700 w-full max-w-4xl h-[80vh] rounded-xl shadow-2xl relative">
                  <button
                     onClick={() => setShowConfig(false)}
                     className="absolute top-4 right-4 text-neutral-400 hover:text-white z-10 p-2 bg-neutral-800 rounded-full"
                  >
                     <X className="w-6 h-6" />
                  </button>
                  <ConfigPanel onClose={() => setShowConfig(false)} onLoadCase={handleLoadCase} />
               </div>
            </div>
         )}

      </div>
   );
}
