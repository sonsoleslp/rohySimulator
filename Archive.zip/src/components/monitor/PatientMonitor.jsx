import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Heart, Activity, Wind, Thermometer, Bell, Settings, Play, Pause, AlertCircle, Menu, X, Monitor, User, FileJson, FastForward } from 'lucide-react';
import defaultSettings from '../../settings.json';

/**
 * ADVANCED ECG GENERATION UTILITIES
 * Based on a simplified McSharry driven cardiovascular system model (Sum of Gaussians)
 */

// Gaussian function: a * exp( - (t - b)^2 / (2 * c^2) )
const gaussian = (t, a, b, c) => a * Math.exp(-Math.pow(t - b, 2) / (2 * Math.pow(c, 2)));

// Skewed Gaussian for T-wave asymmetry (approx)
const skewGaussian = (t, a, b, c, skew) => {
   // Determine effective center shift based on skew
   // This is a rough approximation: skew > 0 stretches the right tail
   const x = (t - b) / c;
   // Standard normal PDF
   const pdf = Math.exp(-0.5 * x * x);
   // Error function approx for CDF
   const cdf = 0.5 * (1 + Math.tanh(skew * x * 0.79788));
   return a * pdf * cdf; // Amplitude scaling might be off, but visually it works
};


// Standard P-QRS-T parameters (approximate) relative to a beat duration of 1.0 at 60 BPM
// [Amplitude, Center (time), Width]
// We will adapt C (Width) based on HR to keep QRS constant duration in ms
const BASE_WAVES = {
   P: { a: 0.15, b: 0.20, c: 0.04 },
   Q: { a: -0.15, b: 0.35, c: 0.02 },
   R: { a: 1.0, b: 0.38, c: 0.03 },
   S: { a: -0.25, b: 0.42, c: 0.03 },
   T: { a: 0.3, b: 0.70, c: 0.08 },
};

const GenerateECGRaw = (phase, options = {}) => {
   let y = 0;
   const {
      stElev = 0,     // ST Elevation/Depression
      tInv = 0,
      wideQRS = 0,
      noise = 0,
      hr = 80         // Current Heart Rate to scale widths
   } = options;

   // Width Scaling:
   // At 60 BPM (1000ms), c=0.03 is ~30ms width in phase space? No.
   // Phase 0..1 = 1000ms. 0.03 * 1000 = 30ms sigma. 
   // QRS duration is ~3*sigma * 2 approx 100ms. Roughly correct.
   // If HR = 120 (500ms), Phase 0..1 = 500ms.
   // If we keep c=0.03, width is 0.03*500 = 15ms. TOO THIN.
   // We need width in ms to be constant.
   // New C = (Old C * 1000) / CurrentDuration
   //       = (Old C * 1000) / (60000 / HR)
   //       = Old C * (HR / 60)

   const widthScale = Math.max(1, hr / 60);

   // 1. P Wave (absent in AFib/VFib)
   if (!options.hideP) {
      y += gaussian(phase, BASE_WAVES.P.a, BASE_WAVES.P.b, BASE_WAVES.P.c * widthScale);
   } else if (options.afibNoise) {
      // F-waves for AFib
      y += Math.sin(phase * 40) * 0.03 + Math.sin(phase * 53) * 0.02;
   }

   // 2. QRS Complex
   const qrsW = (wideQRS > 0 ? 2.5 : 1.0) * widthScale;

   if (options.isPVC) {
      // PVC: Wide chaotic
      y += gaussian(phase, 0.8, 0.4, 0.12 * widthScale);
      y -= gaussian(phase, 0.4, 0.55, 0.15 * widthScale);
   } else if (!options.isVfib) {
      // Normal QRS
      y += gaussian(phase, BASE_WAVES.Q.a, BASE_WAVES.Q.b, BASE_WAVES.Q.c * qrsW);
      y += gaussian(phase, BASE_WAVES.R.a, BASE_WAVES.R.b, BASE_WAVES.R.c * qrsW);
      y += gaussian(phase, BASE_WAVES.S.a, BASE_WAVES.S.b, BASE_WAVES.S.c * qrsW);
   }

   // 3. T Wave & ST Segment
   if (!options.isPVC && !options.isVfib) {
      const stOffset = stElev * 0.2;
      let tAmp = BASE_WAVES.T.a * (tInv ? -1 : 1);

      // ST Bridge
      if (Math.abs(stElev) > 0.1) {
         y += gaussian(phase, stOffset, 0.55, 0.15 * widthScale);
         tAmp += stOffset;
      }

      // Asymmetric T Wave (skewed)
      // T wave duration narrows slightly with exercise but less than diastole?
      // Actually QT shortens. We scale T width somewhat but maybe less than full HR ratio?
      // Let's stick to widthScale for now to avoid it vanishing.
      // Skew factor 2.0 makes it rise fast fall slow? Or vice versa.
      // Standard T rises slower than it falls? No, steep dropoff?
      // Actually "Normally, the T wave is asymmetrical, the first half having a more gradual slope than the second half."
      // Skew > 0 stretches right side? Let's try 0.

      // Using basic gaussian for now but slightly shifted
      y += gaussian(phase, tAmp, BASE_WAVES.T.b, BASE_WAVES.T.c * widthScale * 1.2);
   }

   // 4. V-Fib Chaos
   if (options.isVfib) {
      y = Math.sin(phase * 15) * 0.3 + Math.sin(phase * 19) * 0.2 + (Math.random() - 0.5) * 0.1;
   }

   // 5. Asystole
   if (options.isAsystole) {
      y = (Math.random() - 0.5) * 0.02; // Slight baseline wander line
   }

   // 6. Noise / Baseline Wander
   if (noise > 0) {
      y += (Math.random() - 0.5) * (noise * 0.05);
   }

   // Add consistent respiration wander
   // Passed in options? Or just hardcode a slow sine here?
   // We don't have time context easily here. Let's skip for now.

   return y;
};


export default function PatientMonitor({ caseParams }) {
   // --- Refs for Canvas & Buffers ---
   const canvasRef = useRef(null);
   const ecgCanvasRef = useRef(null);
   const plethCanvasRef = useRef(null);
   const respCanvasRef = useRef(null);

   // Data Buffers (Circular or simple push/shift)
   // We use simple arrays and shift for this demo as performance is fine for < 2000 points
   const ecgBuffer = useRef(new Array(1000).fill(0));
   const plethBuffer = useRef(new Array(1000).fill(0));
   const respBuffer = useRef(new Array(1000).fill(0));

   // --- Simulation State ---
   const [isPlaying, setIsPlaying] = useState(true);
   const [lastFrameTime, setLastFrameTime] = useState(0);

   // Rhythm & Conditions (Declared early due to dependency usage) // Moved UP
   const [rhythm, setRhythm] = useState('NSR'); // NSR, AFib, VTach, VFib, Asystole
   const [conditions, setConditions] = useState({
      pvc: false, // Premature Ventricular Contractions (random)
      stElev: 0,  // -5 to +5 mm
      tInv: false,
      wideQRS: false,
      noise: 0
   });

   // Patient Parameters (Target/Set values)
   const [params, setParams] = useState({
      hr: 80,
      spo2: 98,
      rr: 16,
      bpSys: 120,
      bpDia: 80,
      temp: 37.0,
      etco2: 38
   });

   // Display Vitals (Fluctuating values)
   const [displayVitals, setDisplayVitals] = useState(params);

   // Physics params ref to avoid dependency loops in animation
   const simulationParams = useRef(params);

   // Sync params changes to simulation ref immediately
   useEffect(() => {
      simulationParams.current = params;
      // If we are NOT running a scenario, update display immediately.
      // If running a scenario, the engine loop updates displayVitals, so we might fight it.
      // But typically manual changes shouldn't happen during scenario auto-play.
      if (!activeScenario) {
         setDisplayVitals(params);
      }
   }, [params]);

   // --- Scenario Engine ---
   const [activeScenario, setActiveScenario] = useState(null); // 'mi_progression', etc.
   const [scenarioTime, setScenarioTime] = useState(0); // seconds
   const [scenarioPlaying, setScenarioPlaying] = useState(false);

   // Load Scenarios into State (to allow custom additions)
   const [scenarioList, setScenarioList] = useState(defaultSettings.scenarios);

   // Custom Trend Builder State
   const [trendTarget, setTrendTarget] = useState({ hr: 100, spo2: 95, bpSys: 120, bpDia: 80, duration: 300 });
   const [showBuilder, setShowBuilder] = useState(false);

   // Create & Run Custom Trend
   const runCustomTrend = () => {
      const id = `custom_${Date.now()}`;
      const newScenario = {
         id,
         name: `Custom Trend (${(trendTarget.duration / 60).toFixed(1)}m)`,
         description: `Linear trend to HR ${trendTarget.hr}, SpO2 ${trendTarget.spo2}%`,
         timeline: [
            { time: 0, params: { ...params }, conditions: { ...conditions } }, // Start at current
            {
               time: trendTarget.duration,
               params: {
                  hr: trendTarget.hr,
                  spo2: trendTarget.spo2,
                  bpSys: trendTarget.bpSys,
                  bpDia: trendTarget.bpDia,
                  rr: params.rr
               }
            }
         ]
      };

      setScenarioList(prev => [...prev, newScenario]);
      setActiveScenario(id);
      setScenarioTime(0);
      setScenarioPlaying(true);
      setShowBuilder(false);
   };

   // Engine Loop
   useEffect(() => {
      if (!activeScenario || !scenarioPlaying) return;

      const interval = setInterval(() => {
         setScenarioTime(t => {
            const nextTime = t + 1;
            const scenario = scenarioList.find(s => s.id === activeScenario);
            if (!scenario) return nextTime;

            // Find current segment
            const timeline = scenario.timeline.sort((a, b) => a.time - b.time);

            // 1. Find keyframes surrounding current time
            // keyframe A <= time < keyframe B
            let idx = timeline.findIndex(k => k.time > nextTime);
            if (idx === -1) idx = timeline.length; // Past last frame

            const toFrame = timeline[idx < timeline.length ? idx : timeline.length - 1];
            const fromFrame = timeline[idx > 0 ? idx - 1 : 0];

            if (toFrame && fromFrame && toFrame !== fromFrame) {
               // Interpolate
               const totalDur = toFrame.time - fromFrame.time;
               const progress = (nextTime - fromFrame.time) / totalDur; // 0 to 1

               const lerp = (start, end, p) => start + (end - start) * p;

               // Interpolate Params
               const newParams = { ...params }; // Start with current or base? 
               // Better: Interpolate between the *values defined in the frames*.
               // If a value is missing in 'from', use current state? No, assume defined or carry over.
               // Simplified: We interpolate everything defined in 'toFrame'.

               const getVal = (obj, key, def) => (obj && obj[key] !== undefined) ? obj[key] : def;

               const pKeys = ['hr', 'spo2', 'rr', 'bpSys', 'bpDia'];
               const interpolatedParams = {};

               pKeys.forEach(key => {
                  const startVal = getVal(fromFrame.params, key, params[key]);
                  const endVal = getVal(toFrame.params, key, startVal);
                  interpolatedParams[key] = Math.round(lerp(startVal, endVal, progress));
               });

               setParams(prev => ({ ...prev, ...interpolatedParams }));

               // Interpolate Conditions (Float values like stElev)
               // Boolean/Enum conditions (rhythm, pvc, wideQRS) usually switch at the Keyframe time
               const cKeys = ['stElev', 'noise'];
               const interpolatedConds = {};
               cKeys.forEach(key => {
                  const startVal = getVal(fromFrame.conditions, key, conditions[key]);
                  const endVal = getVal(toFrame.conditions, key, startVal);
                  interpolatedConds[key] = parseFloat(lerp(startVal, endVal, progress).toFixed(2));
               });

               // Discrete switches happening EXACTLY at frame time
               // We check if we just crossed a frame time
               // Or simplified: Use 'fromFrame' discrete values as the "current state"
               // But better: If we are close to 'fromFrame.time', apply its discrete settings one-shot?
               // Actually, 'fromFrame' is the state we are LEAVING or IN.
               // We should ensure the discrete state matches 'fromFrame'.

               const discKeys = ['pvc', 'wideQRS', 'tInv'];
               discKeys.forEach(key => {
                  if (fromFrame.conditions && fromFrame.conditions[key] !== undefined) {
                     interpolatedConds[key] = fromFrame.conditions[key];
                  }
               });

               if (fromFrame.rhythm) {
                  setRhythm(fromFrame.rhythm);
               }

               setConditions(prev => ({ ...prev, ...interpolatedConds }));
            } else if (toFrame && nextTime >= toFrame.time) {
               // We are sitting at or past the last frame
               // Ensure final state
               if (toFrame.params) setParams(prev => ({ ...prev, ...toFrame.params }));
               if (toFrame.rhythm) setRhythm(toFrame.rhythm);
               if (toFrame.conditions) setConditions(prev => ({ ...prev, ...toFrame.conditions }));
            }

            return nextTime;
         });
      }, 1000); // Update scenario logic every second (interpolation granularity)

      return () => clearInterval(interval);
   }, [activeScenario, scenarioPlaying, params, conditions]); // Params/conditions deps might cause jitter logic loops needed? 
   // Actually, we are calling setParams, which triggers the other useEffect that updates simulationParams.
   // That's fine.

   // Vital Signs Fluctuation Loop (Jitter)
   useEffect(() => {
      // Jitter only if NOT in a critical arrested state (though noise might exist)
      // If scenario is driving, we still want jitter ON TOP of the scenario path?
      // Yes, scenario sets the "Target" params, this loop adds noise to "Display".

      const interval = setInterval(() => {
         const p = simulationParams.current;
         const rhythmType = rhythm; // Closure capture or ref? Rhythm needs to be in ref too if used here

         if (rhythmType === 'Asystole' || rhythmType === 'VFib') {
            // Don't fluctuate 0
            setDisplayVitals(prev => ({ ...prev, hr: 0, spo2: "?", bpSys: "?", bpDia: "?" }));
            return;
         }

         // Calculate Noise
         const noiseHR = Math.floor(Math.random() * 5) - 2; // -2 to +2
         const noiseSpO2 = Math.random() > 0.8 ? -1 : 0;
         const noiseRR = Math.floor(Math.random() * 3) - 1;
         const noiseSys = Math.floor(Math.random() * 5) - 2;
         const noiseDia = Math.floor(Math.random() * 4) - 2;

         const newVitals = {
            ...p,
            hr: Math.max(0, p.hr + noiseHR),
            spo2: Math.min(100, Math.max(0, p.spo2 + noiseSpO2)),
            rr: Math.max(0, p.rr + noiseRR),
            bpSys: p.bpSys + noiseSys,
            bpDia: p.bpDia + noiseDia,
         };

         setDisplayVitals(newVitals);

         // Update physics ref so wave speed matches display? 
         // Actually, wave speed should probably stay closer to target to avoid jerky waves,
         // but slight match is good. Let's update simulationParams to match display for a second?
         // No, keep simulationParams as SETTINGS, but maybe add a 'current' field.
         // For simplicity, let's just let the physics read the jittered value from a separate ref if we wanted perfect sync.
         // But here we will stick to physics reading 'simulationParams' (target) to keep regular rhythm,
         // and just show jittered numbers. 

      }, 2000);
      return () => clearInterval(interval);
   }, [rhythm]); // Restart if Rhythm changes



   const [controlsOpen, setControlsOpen] = useState(false);
   const [activeTab, setActiveTab] = useState('rhythm'); // rhythm, vitals, display

   // Internal Physics State
   const physics = useRef({
      phase: 0.0,      // 0.0 to 1.0 (cardiac cycle position)
      respPhase: 0.0,  // 0.0 to 1.0 (respiratory cycle)
      lastBeatTime: 0,
      nextBeatDuration: 750, // ms
      pvcChance: 0.0,  // Dynamic probability
   });

   // --- Animation Loop ---
   useEffect(() => {
      let animationId;
      let lastTime = performance.now();

      const loop = (time) => {
         const dt = time - lastTime;
         lastTime = time;

         if (isPlaying) {
            updateSimulation(dt);
            drawWaveforms();
         }

         animationId = requestAnimationFrame(loop);
      };

      animationId = requestAnimationFrame(loop);
      return () => cancelAnimationFrame(animationId);
   }, [isPlaying, params, rhythm, conditions]);

   // --- Physics Update ---
   const updateSimulation = (dt) => {
      const p = physics.current;

      // 1. Calculate Cardiac Phase
      let currentHR = params.hr;

      // Rhythm Logic Overrides
      if (rhythm === 'VFib') currentHR = 0; // Chaotic phase, HR meaningless
      if (rhythm === 'Asystole') currentHR = 0;

      // Cycle duration in ms
      let targetDuration = currentHR > 0 ? (60000 / currentHR) : 1000;

      // Arrhythmia variability
      if (rhythm === 'AFib') {
         // AFib: Irregularly Irregular. 
         // Base duration on HR but add significant variance per beat
         targetDuration = (60000 / params.hr) + (Math.random() * 400 - 200);
      }

      // Advance Phase
      if (rhythm === 'Asystole') {
         p.phase = 0; // Stuck
      } else if (rhythm === 'VFib') {
         p.phase += dt / 200; // Fast chaos
      } else {
         // Normal beat progression
         p.phase += dt / p.nextBeatDuration;
         if (p.phase >= 1.0) {
            p.phase = 0; // Beat Reset
            p.nextBeatDuration = targetDuration; // New interval for next beat

            // Random PVC trigger
            if (conditions.pvc && Math.random() < 0.15) {
               // Shorten next beat for PVC (early beat)
               p.nextBeatDuration *= 0.6;
               p.isNextPVC = true;
            } else {
               p.isNextPVC = false;
            }
         }
      }

      // 2. Advance Respiratory Phase
      const respDuration = params.rr > 0 ? (60000 / params.rr) : 10000;
      p.respPhase += dt / respDuration;
      if (p.respPhase >= 1.0) p.respPhase = 0;


      // 3. Generate Data Points
      const isPVC = p.isNextPVC;

      // ECG
      const ecgOpts = {
         stElev: conditions.stElev,
         tInv: conditions.tInv,
         wideQRS: conditions.wideQRS ? 1 : 0,
         noise: conditions.noise,
         hideP: rhythm === 'AFib' || rhythm === 'VTach',
         afibNoise: rhythm === 'AFib',
         isPVC: isPVC,
         isVfib: rhythm === 'VFib',
         isAsystole: rhythm === 'Asystole',
         hr: currentHR // Pass HR for width scaling
      };

      const ecgVal = GenerateECGRaw(p.phase, ecgOpts);
      ecgBuffer.current.shift();
      ecgBuffer.current.push(ecgVal);

      // PLETH (SpO2)
      let plethVal = 0;
      if (currentHR > 0) {
         const plethPhase = (p.phase - 0.1 + 1.0) % 1.0; // Delayed
         // High HR attenuates pulse slightly
         const amp = currentHR > 140 ? 0.7 : 1.0;

         if (plethPhase < 0.2) {
            plethVal = Math.sin(plethPhase * 5 * Math.PI / 2) * amp;
         } else {
            const decay = 1 - ((plethPhase - 0.2) / 0.8);
            const notch = Math.exp(-Math.pow(plethPhase - 0.5, 2) / 0.005) * 0.15 * amp;
            plethVal = (decay * 0.8 + notch);
         }
      }
      plethVal *= (1 + 0.1 * Math.sin(p.respPhase * 2 * Math.PI));

      plethBuffer.current.shift();
      plethBuffer.current.push(plethVal);

      // RESP
      const respVal = Math.sin(p.respPhase * 2 * Math.PI);
      respBuffer.current.shift();
      respBuffer.current.push(respVal);
   };

   // Helper to switch rhythm and set appropriate defaults
   const handleRhythmChange = (r) => {
      setRhythm(r);
      const updates = {};

      switch (r) {
         case 'NSR':
            updates.hr = 80;
            updates.spo2 = 98;
            break;
         case 'AFib':
            updates.hr = 110; // Rapid ventricular response
            updates.spo2 = 95;
            break;
         case 'VTach':
            updates.hr = 160;
            updates.spo2 = 88;
            updates.bpSys = 90; // Hypotension
            break;
         case 'VFib':
         case 'Asystole':
            // HR is 0 effectively
            break;
      }

      if (Object.keys(updates).length > 0) {
         setParams(p => ({ ...p, ...updates }));
      }
   };

   // --- Drawing ---
   const drawWaveforms = () => {
      drawCanvas(ecgCanvasRef.current, ecgBuffer.current, '#00ff00', 2, 1);
      drawCanvas(plethCanvasRef.current, plethBuffer.current, '#0ea5e9', 1.5, 0.5); // Cyan
      drawCanvas(respCanvasRef.current, respBuffer.current, '#f59e0b', 1.5, 0); // Amber/Yellow
   };

   const drawCanvas = (canvas, data, color, lineWidth, gain) => {
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const w = canvas.width;
      const h = canvas.height;

      ctx.clearRect(0, 0, w, h);

      // Grid (faint)
      ctx.strokeStyle = '#333';
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      // Vertical lines every 50px
      for (let x = 0; x < w; x += 50) { ctx.moveTo(x, 0); ctx.lineTo(x, h); }
      ctx.stroke();

      // Signal
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;
      ctx.lineJoin = 'round';
      ctx.beginPath();

      const step = w / data.length;
      // Auto-center baseline
      const baseline = h / 2;
      const scale = -(h * 0.4); // Negative to flip Y (up is positive voltage)

      for (let i = 0; i < data.length; i++) {
         const x = i * step;
         const y = baseline + (data[i] * scale * (gain || 1));
         if (i === 0) ctx.moveTo(x, y);
         else ctx.lineTo(x, y);
      }
      ctx.stroke();
   };

   // --- Resize Handler ---
   const containerRef = useRef(null);

   useEffect(() => {
      if (!containerRef.current) return;

      const handleResize = () => {
         [ecgCanvasRef, plethCanvasRef, respCanvasRef].forEach(ref => {
            if (ref.current) {
               const rect = ref.current.getBoundingClientRect();
               // Only update if dimensions differ significantly to avoid loops
               if (ref.current.width !== rect.width * 2 || ref.current.height !== rect.height * 2) {
                  ref.current.width = rect.width * 2;
                  ref.current.height = rect.height * 2;
               }
            }
         });
      };

      const observer = new ResizeObserver(() => {
         window.requestAnimationFrame(handleResize);
      });

      observer.observe(containerRef.current);
      handleResize(); // Initial

      return () => observer.disconnect();
   }, []);

   return (
      <div ref={containerRef} className="flex flex-col h-full bg-black text-gray-100 font-sans overflow-hidden select-none">

         {/* HEADER */}
         <div className="flex items-center justify-between px-4 py-3 bg-neutral-900 border-b border-neutral-800 shrink-0 z-20">
            <div className="flex items-center gap-4">
               <div className="bg-neutral-800 p-2 rounded-md">
                  <Monitor className="w-5 h-5 text-blue-400" />
               </div>
               <div>
                  <h1 className="text-lg font-bold tracking-tight text-white leading-tight">ICU MONITOR 01</h1>
                  <div className="flex items-center gap-2 text-xs text-neutral-400">
                     <User className="w-3 h-3" />
                     <span>DOE, JOHN • 45M • ID: 899212</span>
                  </div>
               </div>
            </div>

            <div className="flex items-center gap-3">
               <div className="text-right mr-4 hidden md:block">
                  <div className="text-sm font-bold text-neutral-300">{new Date().toLocaleTimeString()}</div>
                  <div className="text-xs text-neutral-500">{new Date().toLocaleDateString()}</div>
               </div>

               <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className={`p-2 rounded-full transition-colors ${isPlaying ? 'bg-neutral-800 text-neutral-400 hover:bg-neutral-700' : 'bg-green-900/40 text-green-400 animate-pulse'}`}
               >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
               </button>

               <button
                  className={`p-2 rounded-full transition-colors ${conditions.noise > 0 || params.hr > 120 ? 'bg-red-900/40 text-red-500 animate-pulse' : 'bg-neutral-800 text-neutral-400'}`}
               >
                  <Bell className="w-5 h-5" />
               </button>

               <button
                  onClick={() => setControlsOpen(true)}
                  className="p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-md transition-colors shadow-lg shadow-blue-900/20"
               >
                  <Settings className="w-5 h-5" />
               </button>
            </div>
         </div>

         {/* MAIN LAYOUT */}
         <div className="flex flex-1 relative overflow-hidden">

            {/* WAVEFORMS (LEFT) */}
            <div className="flex-1 flex flex-col bg-black relative">

               {/* Channel 1: ECG */}
               <div className="flex-1 min-h-[160px] border-b border-neutral-800/50 relative group">
                  <div className="absolute top-2 left-3 z-10 font-mono text-sm font-bold text-green-500 select-none">
                     II <span className="text-xs font-normal opacity-70 ml-1">1mV</span>
                  </div>
                  <canvas ref={ecgCanvasRef} className="w-full h-full block" />
                  <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-black via-transparent to-transparent pointer-events-none" />
               </div>

               {/* Channel 2: PLETH */}
               <div className="h-32 border-b border-neutral-800/50 relative">
                  <div className="absolute top-2 left-3 z-10 font-mono text-sm font-bold text-sky-500 select-none">
                     PLETH
                  </div>
                  <canvas ref={plethCanvasRef} className="w-full h-full block" />
               </div>

               {/* Channel 3: RESP */}
               <div className="h-32 border-b border-neutral-800/50 relative">
                  <div className="absolute top-2 left-3 z-10 font-mono text-sm font-bold text-amber-500 select-none">
                     RESP <span className="text-xs font-normal opacity-70 ml-1">Imp</span>
                  </div>
                  <canvas ref={respCanvasRef} className="w-full h-full block" />
               </div>

            </div>

            {/* VITALS (RIGHT SIDEBAR) */}
            <div className="w-64 bg-neutral-900/50 backdrop-blur-sm border-l border-neutral-800 flex flex-col shrink-0 overflow-y-auto">

               {/* HR Box */}
               <div className="flex-1 border-b border-neutral-800 p-4 flex flex-col justify-center relative overflow-hidden">
                  <div className="absolute top-2 left-3 text-green-500 font-bold text-sm flex items-center gap-1">
                     <Heart className="w-3 h-3" /> HR
                  </div>
                  <div className="text-right relative z-10">
                     <div className={`text-7xl font-mono font-bold tracking-tighter ${rhythm === 'Asystole' ? 'text-red-500' : 'text-green-500'}`}>
                        {rhythm === 'Asystole' || rhythm === 'VFib' ? '---' : displayVitals.hr}
                     </div>
                     <div className="text-neutral-500 text-xs mt-[-5px]">bpm</div>
                  </div>
               </div>

               {/* SpO2 Box */}
               <div className="h-32 border-b border-neutral-800 p-4 flex flex-col justify-center relative">
                  <div className="absolute top-2 left-3 text-sky-500 font-bold text-sm">SpO2</div>
                  <div className="text-right">
                     <div className="text-5xl font-mono font-bold tracking-tighter text-sky-500">
                        {displayVitals.spo2}<span className="text-2xl opacity-50">%</span>
                     </div>
                  </div>
                  {/* Signal Quality Bar */}
                  <div className="absolute bottom-3 left-4 right-4 h-1 bg-neutral-800 rounded overflow-hidden">
                     <div className="h-full bg-sky-600 w-[90%]" />
                  </div>
               </div>

               {/* NIBP Box */}
               <div className="h-32 border-b border-neutral-800 p-4 flex flex-col justify-center relative">
                  <div className="absolute top-2 left-3 text-red-500 font-bold text-sm">NIBP</div>
                  <div className="text-right mt-2">
                     <div className="text-4xl font-mono font-bold tracking-tighter text-red-100 leading-none">
                        {displayVitals.bpSys}/{displayVitals.bpDia}
                     </div>
                     <div className="text-red-400 text-sm mt-1 font-mono">
                        ({Math.round((displayVitals.bpSys + 2 * displayVitals.bpDia) / 3)})
                     </div>
                  </div>
                  <div className="absolute bottom-2 left-3 text-[10px] text-neutral-500">
                     AUTO 15min • <span className="text-neutral-300">14:02</span>
                  </div>
               </div>

               {/* NIBP Box */}
               <div className="h-32 border-b border-neutral-800 p-4 flex flex-col justify-center relative">
                  <div className="absolute top-2 left-3 text-amber-500 font-bold text-sm">RESP</div>
                  <div className="text-right">
                     <div className="text-5xl font-mono font-bold tracking-tighter text-amber-500">
                        {displayVitals.rr}
                     </div>
                     <div className="text-neutral-500 text-xs">rpm</div>
                  </div>
               </div>

            </div>
         </div>

         {/* CONTROLS OVERLAY (DRAWER) */}
         <div
            className={`fixed inset-y-0 right-0 w-96 bg-neutral-900 border-l border-neutral-700 shadow-2xl transform transition-transform duration-300 ease-out z-50 flex flex-col ${controlsOpen ? 'translate-x-0' : 'translate-x-full'}`}
         >
            <div className="flex items-center justify-between p-4 border-b border-neutral-800 bg-neutral-800">
               <h2 className="text-white font-bold text-lg flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-500" />
                  Simulator Controls
               </h2>
               <button onClick={() => setControlsOpen(false)} className="text-neutral-400 hover:text-white">
                  <X className="w-6 h-6" />
               </button>
            </div>

            {/* Tabs */}
            <div className="flex p-1 bg-neutral-900 border-b border-neutral-800">
               {['rhythm', 'vitals', 'scenarios'].map(tab => (
                  <button
                     key={tab}
                     onClick={() => setActiveTab(tab)}
                     className={`flex-1 py-2 text-sm font-bold uppercase tracking-wider rounded-md transition-colors ${activeTab === tab ? 'bg-neutral-800 text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
                  >
                     {tab}
                  </button>
               ))}
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6">

               {activeTab === 'scenarios' && (
                  <div className="space-y-6">
                     <div className="bg-neutral-800/50 p-4 rounded-lg border border-neutral-800">
                        <div className="flex justify-between items-center mb-4">
                           <h3 className="text-white font-bold flex items-center gap-2">
                              <FileJson className="w-5 h-5 text-purple-500" />
                              Scenarios
                           </h3>
                           <div className="text-xs font-mono text-neutral-400">
                              {scenarioTime}s
                           </div>
                        </div>

                        {activeScenario && (
                           <div className="mb-4 flex items-center gap-2 bg-black/40 p-2 rounded">
                              <button
                                 onClick={() => setScenarioPlaying(!scenarioPlaying)}
                                 className={`p-2 rounded-full ${scenarioPlaying ? 'bg-red-500/20 text-red-500' : 'bg-green-500/20 text-green-500'}`}
                              >
                                 {scenarioPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                              </button>
                              <div className="flex-1">
                                 <div className="text-xs text-neutral-400 uppercase">Current</div>
                                 <div className="text-sm font-bold text-white max-w-[150px] truncate">
                                    {scenarioList.find(s => s.id === activeScenario)?.name}
                                 </div>
                              </div>
                              <button
                                 onClick={() => {
                                    setScenarioPlaying(false);
                                    setScenarioTime(0);
                                    setActiveScenario(null);
                                 }}
                                 className="text-xs text-neutral-500 hover:text-white underline"
                              >
                                 Stop/Reset
                              </button>
                           </div>
                        )}

                        {/* Custom Trend Button */}
                        {!showBuilder ? (
                           <button
                              onClick={() => setShowBuilder(true)}
                              className="w-full py-3 mb-4 rounded border-2 border-dashed border-neutral-700 text-neutral-400 font-bold text-sm uppercase hover:bg-neutral-800 hover:border-neutral-500 transition-all flex items-center justify-center gap-2"
                           >
                              <Settings className="w-4 h-4" /> Build Custom Scenario
                           </button>
                        ) : (
                           <div className="mb-4 bg-neutral-900 border border-neutral-700 p-3 rounded-md space-y-3 animate-in fade-in slide-in-from-top-2">
                              <div className="flex justify-between items-center text-xs font-bold text-neutral-400 uppercase">
                                 <span>Target Values</span>
                                 <button onClick={() => setShowBuilder(false)}><X className="w-4 h-4" /></button>
                              </div>
                              <div className="grid grid-cols-2 gap-2">
                                 <div className="space-y-1">
                                    <label className="text-[10px] text-neutral-500">HR (bpm)</label>
                                    <input type="number"
                                       value={trendTarget.hr}
                                       onChange={e => setTrendTarget({ ...trendTarget, hr: parseInt(e.target.value) })}
                                       className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-sm text-green-500 font-mono"
                                    />
                                 </div>
                                 <div className="space-y-1">
                                    <label className="text-[10px] text-neutral-500">SpO2 (%)</label>
                                    <input type="number"
                                       value={trendTarget.spo2}
                                       onChange={e => setTrendTarget({ ...trendTarget, spo2: parseInt(e.target.value) })}
                                       className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-sm text-sky-500 font-mono"
                                    />
                                 </div>
                                 <div className="space-y-1">
                                    <label className="text-[10px] text-neutral-500">BP Sys</label>
                                    <input type="number"
                                       value={trendTarget.bpSys}
                                       onChange={e => setTrendTarget({ ...trendTarget, bpSys: parseInt(e.target.value) })}
                                       className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-sm text-red-400 font-mono"
                                    />
                                 </div>
                                 <div className="space-y-1">
                                    <label className="text-[10px] text-neutral-500">BP Dia</label>
                                    <input type="number"
                                       value={trendTarget.bpDia}
                                       onChange={e => setTrendTarget({ ...trendTarget, bpDia: parseInt(e.target.value) })}
                                       className="w-full bg-neutral-800 border border-neutral-700 rounded px-2 py-1 text-sm text-red-500 font-mono"
                                    />
                                 </div>
                              </div>
                              <div className="space-y-1 pt-2 border-t border-neutral-800">
                                 <div className="flex justify-between">
                                    <label className="text-[10px] text-neutral-500">Trend Duration</label>
                                    <span className="text-[10px] text-blue-400 font-mono font-bold">
                                       {(trendTarget.duration / 60).toFixed(1)} min
                                    </span>
                                 </div>
                                 <div className="flex items-center gap-2">
                                    <span className="text-[10px] text-neutral-600">1m</span>
                                    <input type="range" min="1" max="60" step="1"
                                       value={trendTarget.duration / 60}
                                       onChange={e => setTrendTarget({ ...trendTarget, duration: parseFloat(e.target.value) * 60 })}
                                       className="flex-1 h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                                    />
                                    <span className="text-[10px] text-neutral-600">60m</span>
                                 </div>
                              </div>
                              <button
                                 onClick={runCustomTrend}
                                 className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase rounded shadow-lg shadow-blue-900/20"
                              >
                                 Start Trend
                              </button>
                           </div>
                        )}

                        <div className="space-y-2">
                           {scenarioList.map(s => (
                              <button
                                 key={s.id}
                                 onClick={() => {
                                    if (activeScenario === s.id) return;
                                    setActiveScenario(s.id);
                                    setScenarioTime(0);
                                    setScenarioPlaying(true);
                                 }}
                                 className={`w-full text-left p-3 rounded-md border text-sm transition-all ${activeScenario === s.id ? 'bg-purple-900/30 border-purple-500 text-white' : 'bg-neutral-800 border-neutral-700 text-neutral-400 hover:border-neutral-500'}`}
                              >
                                 <div className="font-bold">{s.name}</div>
                                 <div className="text-xs opacity-70 mt-1">{s.description}</div>
                              </button>
                           ))}
                        </div>
                     </div>
                  </div>
               )}

               {activeTab === 'rhythm' && (
                  <div className="space-y-6">

                     {/* Rhythm Select */}
                     <div className="space-y-2">
                        <label className="text-xs font-bold text-neutral-500 uppercase">Primary Rhythm</label>
                        <div className="grid grid-cols-1 gap-2">
                           {['NSR', 'AFib', 'VTach', 'VFib', 'Asystole'].map(r => (
                              <button
                                 key={r}
                                 onClick={() => handleRhythmChange(r)}
                                 className={`px-4 py-3 rounded-md text-left text-sm font-bold border transition-all ${rhythm === r ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/50' : 'bg-neutral-800 border-neutral-700 text-neutral-400 hover:border-neutral-600'}`}
                              >
                                 {r === 'NSR' ? 'Normal Sinus Rhythm' : r}
                              </button>
                           ))}
                        </div>
                     </div>

                     {/* Ectopics & Noise */}
                     <div className="space-y-2">
                        <label className="text-xs font-bold text-neutral-500 uppercase">Modifiers</label>
                        <div className="space-y-3 bg-neutral-800/50 p-3 rounded-lg border border-neutral-800">

                           <div className="flex items-center justify-between">
                              <span className="text-sm text-neutral-300">PVCs (Ectopics)</span>
                              <button
                                 onClick={() => setConditions(c => ({ ...c, pvc: !c.pvc }))}
                                 className={`w-12 h-6 rounded-full relative transition-colors ${conditions.pvc ? 'bg-green-600' : 'bg-neutral-700'}`}
                              >
                                 <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${conditions.pvc ? 'left-7' : 'left-1'}`} />
                              </button>
                           </div>

                           <div className="flex items-center justify-between">
                              <span className="text-sm text-neutral-300">Wide QRS</span>
                              <button
                                 onClick={() => setConditions(c => ({ ...c, wideQRS: !c.wideQRS }))}
                                 className={`w-12 h-6 rounded-full relative transition-colors ${conditions.wideQRS ? 'bg-green-600' : 'bg-neutral-700'}`}
                              >
                                 <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${conditions.wideQRS ? 'left-7' : 'left-1'}`} />
                              </button>
                           </div>

                           <div className="space-y-1">
                              <div className="flex justify-between text-xs">
                                 <span className="text-neutral-400">ST Deviation</span>
                                 <span className="text-blue-400 font-mono">{conditions.stElev > 0 ? '+' : ''}{conditions.stElev} mm</span>
                              </div>
                              <input
                                 type="range" min="-5" max="5" step="0.5"
                                 value={conditions.stElev}
                                 onChange={(e) => setConditions(c => ({ ...c, stElev: parseFloat(e.target.value) }))}
                                 className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer"
                              />
                           </div>

                           <div className="space-y-1">
                              <div className="flex justify-between text-xs">
                                 <span className="text-neutral-400">Signal Noise</span>
                                 <span className="text-blue-400 font-mono">{conditions.noise}/10</span>
                              </div>
                              <input
                                 type="range" min="0" max="10" step="1"
                                 value={conditions.noise}
                                 onChange={(e) => setConditions(c => ({ ...c, noise: parseInt(e.target.value) }))}
                                 className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer"
                              />
                           </div>

                        </div>
                     </div>

                  </div>
               )}

               {activeTab === 'vitals' && (
                  <div className="space-y-6">
                     {/* HR */}
                     <div className="space-y-2">
                        <div className="flex justify-between items-end">
                           <label className="text-xs font-bold text-neutral-500 uppercase">Heart Rate</label>
                           <span className="text-xl font-mono text-green-500 font-bold">{params.hr}</span>
                        </div>
                        <input
                           type="range" min="20" max="250"
                           value={params.hr}
                           onChange={(e) => setParams(p => ({ ...p, hr: parseInt(e.target.value) }))}
                           className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-green-500"
                        />
                     </div>

                     {/* SpO2 */}
                     <div className="space-y-2">
                        <div className="flex justify-between items-end">
                           <label className="text-xs font-bold text-neutral-500 uppercase">SpO2</label>
                           <span className="text-xl font-mono text-sky-500 font-bold">{params.spo2}%</span>
                        </div>
                        <input
                           type="range" min="50" max="100"
                           value={params.spo2}
                           onChange={(e) => setParams(p => ({ ...p, spo2: parseInt(e.target.value) }))}
                           className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-sky-500"
                        />
                     </div>

                     {/* RR */}
                     <div className="space-y-2">
                        <div className="flex justify-between items-end">
                           <label className="text-xs font-bold text-neutral-500 uppercase">Resp Rate</label>
                           <span className="text-xl font-mono text-amber-500 font-bold">{params.rr}</span>
                        </div>
                        <input
                           type="range" min="0" max="60"
                           value={params.rr}
                           onChange={(e) => setParams(p => ({ ...p, rr: parseInt(e.target.value) }))}
                           className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                        />
                     </div>

                     {/* BP */}
                     <div className="space-y-4 pt-4 border-t border-neutral-800">
                        <div className="space-y-2">
                           <div className="flex justify-between items-end">
                              <label className="text-xs font-bold text-neutral-500 uppercase">Systolic BP</label>
                              <span className="text-lg font-mono text-red-400 font-bold">{params.bpSys}</span>
                           </div>
                           <input
                              type="range" min="50" max="250"
                              value={params.bpSys}
                              onChange={(e) => setParams(p => ({ ...p, bpSys: parseInt(e.target.value) }))}
                              className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-red-500"
                           />
                        </div>
                        <div className="space-y-2">
                           <div className="flex justify-between items-end">
                              <label className="text-xs font-bold text-neutral-500 uppercase">Diastolic BP</label>
                              <span className="text-lg font-mono text-red-500 font-bold">{params.bpDia}</span>
                           </div>
                           <input
                              type="range" min="30" max="150"
                              value={params.bpDia}
                              onChange={(e) => setParams(p => ({ ...p, bpDia: parseInt(e.target.value) }))}
                              className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-red-500"
                           />
                        </div>
                     </div>

                  </div>
               )}

            </div>

            {/* Footer actions */}
            <div className="p-4 border-t border-neutral-800 bg-black/50">
               <button
                  onClick={() => {
                     // Reset to defaults
                     setRhythm('NSR');
                     setParams({ hr: 80, spo2: 98, rr: 16, bpSys: 120, bpDia: 80, temp: 37.0, etco2: 38 });
                     setConditions({ pvc: false, stElev: 0, tInv: false, wideQRS: false, noise: 0 });
                  }}
                  className="w-full py-3 rounded border border-neutral-700 text-neutral-400 font-bold text-xs uppercase hover:bg-neutral-800 transition-colors"
               >
                  Reset Simulation
               </button>
            </div>

         </div>

      </div>
   );
}
