import React from 'react';
import { User } from 'lucide-react';

export default function PatientVisual({ image, context }) {
    return (
        <div className="h-full flex flex-col bg-neutral-900 overflow-hidden relative">
            {/* Full Height Image Area */}
            <div className="absolute inset-0 bg-black/50">
                {image ? (
                    <img src={image} alt="Patient" className="w-full h-full object-cover opacity-80" />
                ) : (
                    <div className="w-full h-full flex items-center justify-center text-neutral-700">
                        <User className="w-24 h-24" />
                    </div>
                )}
            </div>

            {/* Floating Context Bubble (Brief) - Only if exists */}
            {context && (
                <div className="absolute bottom-6 left-6 max-w-[80%] z-10">
                    <div className="bg-black/60 backdrop-blur-md border border-white/10 p-4 rounded-xl text-white/90 text-sm shadow-2xl animate-in fade-in slide-in-from-bottom-4">
                        <p className="font-light italic leading-relaxed">"{context}"</p>
                    </div>
                </div>
            )}
        </div>
    );
}
