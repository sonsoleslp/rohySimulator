import React, { useState, useEffect } from 'react';
import { Settings, Save, Plus, Trash2, Cpu, FileText, Database } from 'lucide-react';
import { LLMService } from '../../services/llmService';

export default function ConfigPanel({ onClose, onLoadCase }) {
    const [activeTab, setActiveTab] = useState('llm'); // llm, cases

    // Provider Configurations
    const PROVIDERS = {
        openai: {
            name: 'OpenAI API',
            defaultBase: 'https://api.openai.com/v1',
            defaultModel: 'gpt-3.5-turbo',
            needsKey: true,
            needsModel: true
        },
        lmstudio: {
            name: 'LM Studio (Local)',
            defaultBase: 'http://localhost:1234/v1',
            defaultModel: 'local-model',
            needsKey: false,
            needsModel: false
        },
        ollama: {
            name: 'Ollama (Local)',
            defaultBase: 'http://localhost:11434/v1',
            defaultModel: 'llama3',
            needsKey: false,
            needsModel: true
        }
    };

    // LLM Config State - Initialize with current service config or defaults
    const [llmConfig, setLlmConfig] = useState(() => {
        const current = LLMService.config;
        // If current provider is generic 'local', map to 'lmstudio' default or keep as is
        let provider = current.provider === 'local' ? 'lmstudio' : current.provider;
        if (!PROVIDERS[provider]) provider = 'openai';

        return {
            provider,
            apiKey: current.apiKey || '',
            baseUrl: current.baseUrl || PROVIDERS[provider].defaultBase,
            model: current.model || PROVIDERS[provider].defaultModel
        };
    });

    // Handle Provider Change
    const handleProviderChange = (newProvider) => {
        const defaults = PROVIDERS[newProvider];
        setLlmConfig({
            provider: newProvider,
            baseUrl: defaults.defaultBase,
            model: defaults.defaultModel,
            apiKey: '' // Clear key on switch for security/cleanliness
        });
    };

    // Cases State
    const [cases, setCases] = useState([]);
    const [selectedCaseId, setSelectedCaseId] = useState(null);
    const [editingCase, setEditingCase] = useState(null);

    // Load Cases on Mount
    useEffect(() => {
        fetch('http://localhost:3000/api/cases')
            .then(res => res.json())
            .then(data => {
                setCases(data.cases || []);
                if (data.cases?.length > 0) setSelectedCaseId(data.cases[0].id);
            })
            .catch(err => console.error("Failed to load cases", err));
    }, []);

    const handleSaveLLM = () => {
        LLMService.setConfig(llmConfig);
        alert('LLM Settings Saved (In-Memory for now)');
    };

    const handleSaveCase = async () => {
        if (!editingCase) return;

        // Auto-generate system prompt if empty (mock logic for now)
        const sysPrompt = editingCase.system_prompt || `You are ${editingCase.name}. ${editingCase.description}`;

        const payload = { ...editingCase, system_prompt: sysPrompt };

        try {
            const res = await fetch('http://localhost:3000/api/cases', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const saved = await res.json();

            // Update List
            setCases(prev => [...prev, saved]);
            setEditingCase(null); // Close editor
            setSelectedCaseId(saved.id);
        } catch (err) {
            console.error(err);
            alert('Failed to save case');
        }
    };

    return (
        <div className="flex flex-col h-full bg-neutral-900 text-white rounded-xl overflow-hidden">

            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-neutral-800 bg-neutral-900 relative">
                <h2 className="text-xl font-bold flex items-center gap-2">
                    <Settings className="w-6 h-6 text-purple-500" />
                    Platform Configuration
                </h2>
                {/* Close handled by parent, but we can have local actions */}
            </div>

            <div className="flex flex-1 overflow-hidden">

                {/* Sidebar */}
                <div className="w-48 bg-neutral-950 border-r border-neutral-800 flex flex-col pt-4">
                    <button
                        onClick={() => setActiveTab('llm')}
                        className={`px-4 py-3 text-left text-sm font-bold flex items-center gap-2 border-l-2 transition-colors ${activeTab === 'llm' ? 'border-purple-500 bg-neutral-900 text-white' : 'border-transparent text-neutral-500 hover:text-neutral-300'}`}
                    >
                        <Cpu className="w-4 h-4" /> LLM Settings
                    </button>
                    <button
                        onClick={() => setActiveTab('cases')}
                        className={`px-4 py-3 text-left text-sm font-bold flex items-center gap-2 border-l-2 transition-colors ${activeTab === 'cases' ? 'border-purple-500 bg-neutral-900 text-white' : 'border-transparent text-neutral-500 hover:text-neutral-300'}`}
                    >
                        <FileText className="w-4 h-4" /> Clinical Cases
                    </button>
                </div>

                {/* Content Area */}
                <div className="flex-1 p-8 overflow-y-auto bg-neutral-900">

                    {/* --- LLM TAB --- */}
                    {activeTab === 'llm' && (
                        <div className="space-y-6 max-w-2xl">
                            <div className="space-y-4">
                                <h3 className="text-lg font-bold border-b border-neutral-800 pb-2">Model Connection</h3>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold text-neutral-500 mb-1 uppercase">Provider</label>
                                        <select
                                            value={llmConfig.provider}
                                            onChange={(e) => handleProviderChange(e.target.value)}
                                            className="w-full bg-neutral-800 border border-neutral-700 rounded p-2 text-sm focus:border-purple-500 outline-none"
                                        >
                                            {Object.entries(PROVIDERS).map(([key, config]) => (
                                                <option key={key} value={key}>{config.name}</option>
                                            ))}
                                        </select>
                                    </div>

                                    {/* BASE URL */}
                                    <div>
                                        <label className="block text-xs font-bold text-neutral-500 mb-1 uppercase">Base URL</label>
                                        <input
                                            type="text"
                                            value={llmConfig.baseUrl}
                                            onChange={(e) => setLlmConfig({ ...llmConfig, baseUrl: e.target.value })}
                                            className="w-full bg-neutral-800 border border-neutral-700 rounded p-2 text-sm font-mono focus:border-purple-500 outline-none"
                                        />
                                        <p className="text-[10px] text-neutral-500 mt-1">Default: {PROVIDERS[llmConfig.provider].defaultBase}</p>
                                    </div>

                                    {/* MODEL NAME (Conditional) */}
                                    {PROVIDERS[llmConfig.provider].needsModel && (
                                        <div>
                                            <label className="block text-xs font-bold text-neutral-500 mb-1 uppercase">Model Name</label>
                                            <input
                                                type="text"
                                                value={llmConfig.model}
                                                onChange={(e) => setLlmConfig({ ...llmConfig, model: e.target.value })}
                                                className="w-full bg-neutral-800 border border-neutral-700 rounded p-2 text-sm focus:border-purple-500 outline-none"
                                                placeholder={PROVIDERS[llmConfig.provider].defaultModel}
                                            />
                                        </div>
                                    )}

                                    {/* API KEY (Conditional) */}
                                    {PROVIDERS[llmConfig.provider].needsKey && (
                                        <div>
                                            <label className="block text-xs font-bold text-neutral-500 mb-1 uppercase">API Key</label>
                                            <div className="relative">
                                                <input
                                                    type="password"
                                                    value={llmConfig.apiKey}
                                                    onChange={(e) => setLlmConfig({ ...llmConfig, apiKey: e.target.value })}
                                                    className="w-full bg-neutral-800 border border-neutral-700 rounded p-2 text-sm focus:border-purple-500 outline-none pr-10"
                                                    placeholder="sk-..."
                                                />
                                                <div className="absolute right-3 top-2.5 text-neutral-500">
                                                    <Cpu className="w-4 h-4" />
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                </div> {/* End Grid */}

                                <div className="flex justify-end pt-4">
                                    <button
                                        onClick={handleSaveLLM}
                                        className="px-6 py-2 bg-purple-600 hover:bg-purple-500 rounded font-bold text-sm shadow-lg shadow-purple-900/20"
                                    >
                                        Apply Settings
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}


                    {/* --- CASES TAB --- */}
                    {activeTab === 'cases' && (
                        <div className="space-y-6">

                            {!editingCase ? (
                                <>
                                    <div className="flex justify-between items-center mb-4">
                                        <h3 className="text-lg font-bold">Manage Cases</h3>
                                        <button
                                            onClick={() => setEditingCase({ name: '', description: '', config: { pages: [] } })}
                                            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded text-sm font-bold"
                                        >
                                            <Plus className="w-4 h-4" /> New Case
                                        </button>
                                    </div>

                                    <div className="grid gap-3">
                                        {cases.map(c => (
                                            <div key={c.id} className="p-4 bg-neutral-800 border border-neutral-700 rounded-lg flex justify-between items-center hover:bg-neutral-800/80">
                                                <div>
                                                    <div className="font-bold text-white">{c.name}</div>
                                                    <div className="text-sm text-neutral-400">{c.description}</div>
                                                </div>
                                                <div className="flex gap-2">
                                                    <button
                                                        onClick={() => {
                                                            if (onLoadCase) onLoadCase(c);
                                                            if (onClose) onClose();
                                                        }}
                                                        className="px-3 py-1.5 bg-green-700 hover:bg-green-600 rounded text-xs font-bold text-white shadow-lg shadow-green-900/20"
                                                    >
                                                        Load
                                                    </button>
                                                    <button onClick={() => setEditingCase(c)} className="p-2 bg-neutral-700 rounded text-xs hover:bg-neutral-600">Edit</button>
                                                    <button className="p-2 bg-red-900/30 text-red-400 rounded text-xs hover:bg-red-900/50">Delete</button>
                                                </div>
                                            </div>
                                        ))}
                                        {cases.length === 0 && (
                                            <div className="text-neutral-500 text-center py-8">No cases found in database.</div>
                                        )}
                                    </div>
                                </>
                            ) : (
                                /* CASE WIZARD */
                                <CaseWizard
                                    caseData={editingCase}
                                    setCaseData={setEditingCase}
                                    onSave={handleSaveCase}
                                    onCancel={() => setEditingCase(null)}
                                />
                            )}

                        </div>
                    )}

                </div>
            </div>
        </div>
    );
}

// Sub-component for the Wizard to keep code clean
function CaseWizard({ caseData, setCaseData, onSave, onCancel }) {
    const [step, setStep] = useState(1);

    // Helper to update deeply nested config
    const updateConfig = (key, value) => {
        setCaseData(prev => ({
            ...prev,
            config: { ...prev.config, [key]: value }
        }));
    };

    const updateDemographics = (key, value) => {
        setCaseData(prev => ({
            ...prev,
            config: {
                ...prev.config,
                demographics: { ...(prev.config?.demographics || {}), [key]: value }
            }
        }));
    };

    const applyPersonaDefaults = () => {
        setCaseData(prev => ({
            ...prev,
            system_prompt: "You are a 55-year-old patient named John Doe. You are currently in the ICU experiencing chest pain. You are anxious but cooperative. You provide short, direct answers.",
            config: {
                ...prev.config,
                persona_type: 'Standard Simulated Patient',
                constraints: 'Do not invent medical history not provided. If asked about something unknown, say you do not know.',
                greeting: 'Doctor, my chest feels like an elephant is sitting on it.',
                demographics: { age: 55, gender: 'Male' }
            }
        }));
    };

    return (
        <div className="flex flex-col h-full max-w-3xl animate-in fade-in slide-in-from-right-4">

            {/* Wizard Header */}
            <div className="flex items-center justify-between border-b border-neutral-800 pb-4 mb-6">
                <div>
                    <h3 className="text-xl font-bold text-white">Case Configuration</h3>
                    <p className="text-xs text-neutral-500">Step {step} of 3</p>
                </div>
                <div className="flex gap-2">
                    <div className={`w-3 h-3 rounded-full ${step >= 1 ? 'bg-purple-500' : 'bg-neutral-800'}`} />
                    <div className={`w-3 h-3 rounded-full ${step >= 2 ? 'bg-purple-500' : 'bg-neutral-800'}`} />
                    <div className={`w-3 h-3 rounded-full ${step >= 3 ? 'bg-purple-500' : 'bg-neutral-800'}`} />
                </div>
            </div>

            <div className="flex-1 overflow-y-auto pr-2">

                {/* STEP 1: PERSONA */}
                {step === 1 && (
                    <div className="space-y-6">
                        <div className="flex justify-between items-end">
                            <h4 className="text-lg font-bold text-purple-400">1. Persona & Behavior</h4>
                            <button onClick={applyPersonaDefaults} className="text-xs bg-neutral-800 hover:bg-neutral-700 px-3 py-1 rounded text-purple-300">
                                Load Standard Defaults
                            </button>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="label-xs">Persona Type</label>
                                <select
                                    value={caseData.config?.persona_type || 'Standard Simulated Patient'}
                                    onChange={e => updateConfig('persona_type', e.target.value)}
                                    className="input-dark"
                                >
                                    <option>Standard Simulated Patient</option>
                                    <option>Difficult/Angry Patient</option>
                                    <option>Pediatric Proxy (Parent)</option>
                                </select>
                            </div>
                            <div>
                                <label className="label-xs">Initial Greeting</label>
                                <input
                                    type="text"
                                    value={caseData.config?.greeting || ''}
                                    onChange={e => updateConfig('greeting', e.target.value)}
                                    className="input-dark"
                                    placeholder="e.g. Help me doctor..."
                                />
                            </div>
                        </div>

                        <div>
                            <label className="label-xs">Behavioral Constraints</label>
                            <textarea
                                value={caseData.config?.constraints || ''}
                                onChange={e => updateConfig('constraints', e.target.value)}
                                className="input-dark h-20"
                                placeholder="e.g. Only speak English. Do not reveal diagnosis."
                            />
                        </div>

                        <div>
                            <label className="label-xs">System Prompt (Master Instruction)</label>
                            <textarea
                                value={caseData.system_prompt || ''}
                                onChange={e => setCaseData({ ...caseData, system_prompt: e.target.value })}
                                className="input-dark h-40 font-mono text-xs"
                                placeholder="You are John Doe..."
                            />
                        </div>
                    </div>
                )}

                {/* STEP 2: DETAILS */}
                {step === 2 && (
                    <div className="space-y-6">
                        <h4 className="text-lg font-bold text-purple-400">2. Case Details & Vitals</h4>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="label-xs">Case Title (Internal)</label>
                                <input
                                    type="text"
                                    value={caseData.name}
                                    onChange={e => setCaseData({ ...caseData, name: e.target.value })}
                                    className="input-dark"
                                />
                            </div>
                            <div>
                                <label className="label-xs">Patient Name (Display)</label>
                                <input
                                    type="text"
                                    value={caseData.config?.patient_name || ''}
                                    onChange={e => updateConfig('patient_name', e.target.value)}
                                    className="input-dark"
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                            <div>
                                <label className="label-xs">Age</label>
                                <input type="number" className="input-dark"
                                    value={caseData.config?.demographics?.age || ''}
                                    onChange={e => updateDemographics('age', e.target.value)}
                                />
                            </div>
                            <div>
                                <label className="label-xs">Gender</label>
                                <select className="input-dark"
                                    value={caseData.config?.demographics?.gender || ''}
                                    onChange={e => updateDemographics('gender', e.target.value)}
                                >
                                    <option value="">Select</option>
                                    <option>Male</option>
                                    <option>Female</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            <div>
                                <label className="label-xs">Initial HR (Monitor)</label>
                                <input type="number" className="input-dark"
                                    value={caseData.config?.hr || 80}
                                    onChange={e => updateConfig('hr', parseInt(e.target.value))}
                                />
                            </div>
                        </div>

                        <div>
                            <label className="label-xs">Case Summary (Description)</label>
                            <textarea
                                value={caseData.description || ''}
                                onChange={e => setCaseData({ ...caseData, description: e.target.value })}
                                className="input-dark h-24"
                                placeholder="Brief summary of the case..."
                            />
                        </div>
                    </div>
                )}

                {/* STEP 3: CLINICAL PAGES */}
                {step === 3 && (
                    <div className="space-y-6">
                        <div className="flex justify-between items-center">
                            <h4 className="text-lg font-bold text-purple-400">3. Clinical Records</h4>
                            <button
                                onClick={() => {
                                    const newPages = [...(caseData.config?.pages || [])];
                                    newPages.push({ title: 'New Section', content: '' });
                                    updateConfig('pages', newPages);
                                }}
                                className="btn-secondary text-xs"
                            >
                                <Plus className="w-3 h-3 mr-1" /> Add Page
                            </button>
                        </div>
                        <p className="text-xs text-neutral-500">These pages are hidden context for the AI and can be requested by the student (e.g. 'Show me the ECG').</p>

                        <div className="space-y-4">
                            {(caseData.config?.pages || []).map((page, idx) => (
                                <div key={idx} className="p-4 bg-neutral-800 border border-neutral-700 rounded-lg animate-in slide-in-from-bottom-2">
                                    <div className="flex justify-between mb-2">
                                        <input
                                            type="text"
                                            value={page.title}
                                            onChange={e => {
                                                const newPages = [...caseData.config.pages];
                                                newPages[idx].title = e.target.value;
                                                updateConfig('pages', newPages);
                                            }}
                                            className="bg-transparent border-b border-neutral-600 font-bold focus:border-purple-500 outline-none text-sm"
                                            placeholder="Page Title (e.g. History)"
                                        />
                                        <button
                                            onClick={() => {
                                                const newPages = caseData.config.pages.filter((_, i) => i !== idx);
                                                updateConfig('pages', newPages);
                                            }}
                                            className="text-neutral-500 hover:text-red-400"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                    <textarea
                                        rows={4}
                                        value={page.content}
                                        onChange={e => {
                                            const newPages = [...caseData.config.pages];
                                            newPages[idx].content = e.target.value;
                                            updateConfig('pages', newPages);
                                        }}
                                        className="input-dark text-xs font-mono"
                                        placeholder="Content for the AI to know..."
                                    />
                                </div>
                            ))}
                            {(caseData.config?.pages || []).length === 0 && (
                                <div className="text-center py-10 bg-neutral-800/50 rounded-lg border border-dashed border-neutral-700 text-neutral-500">
                                    No clinical pages added yet.
                                </div>
                            )}
                        </div>
                    </div>
                )}

            </div>

            {/* Footer Actions */}
            <div className="pt-4 border-t border-neutral-800 flex justify-between mt-4">
                <button onClick={onCancel} className="text-neutral-500 hover:text-white px-4">Cancel</button>
                <div className="flex gap-2">
                    {step > 1 && (
                        <button onClick={() => setStep(s => s - 1)} className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 rounded font-bold text-sm">
                            Back
                        </button>
                    )}
                    {step < 3 ? (
                        <button onClick={() => setStep(s => s + 1)} className="px-6 py-2 bg-purple-600 hover:bg-purple-500 rounded font-bold text-sm">
                            Next
                        </button>
                    ) : (
                        <button onClick={onSave} className="px-6 py-2 bg-green-600 hover:bg-green-500 rounded font-bold text-sm shadow-lg shadow-green-900/20 flex items-center gap-2">
                            <Save className="w-4 h-4" /> Save Case
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}
