/**
 * Service to handle LLM communication and Backend persistence.
 */

// Default Configuration
const DEFAULT_CONFIG = {
    provider: 'openai', // 'openai' or 'local' (compatible with openai format)
    baseUrl: 'http://localhost:11434/v1', // Default Ollama
    apiKey: 'sk-placeholder',
    model: 'llama3'
};

const BACKEND_URL = 'http://localhost:3000/api';

export const LLMService = {

    config: { ...DEFAULT_CONFIG },

    setConfig(newConfig) {
        this.config = { ...this.config, ...newConfig };
    },

    /**
     * Start a new Session for a Case
     */
    async startSession(caseId, studentName = 'Student') {
        try {
            const res = await fetch(`${BACKEND_URL}/sessions`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ case_id: caseId, student_name: studentName })
            });
            const data = await res.json();
            return data.id; // Session ID
        } catch (err) {
            console.error('Failed to start session', err);
            return null;
        }
    },

    /**
     * Send Message to LLM and Log to Backend
     */
    async sendMessage(sessionId, messages, systemPrompt) {
        // 1. Log User Message
        const lastMsg = messages[messages.length - 1];
        if (lastMsg.role === 'user') {
            await this.logInteraction(sessionId, 'user', lastMsg.content);
        }

        // 2. Prepare Payload for LLM
        // If we want the system prompt to be dynamic based on the case, we inject it here.
        const conversation = [
            { role: 'system', content: systemPrompt || 'You are a patient.' },
            ...messages
        ];

        try {
            // 3. Call LLM (Via Backend Proxy to avoid CORS)
            const headers = { 'Content-Type': 'application/json' };
            const isLocal = this.config.provider === 'lmstudio' || this.config.provider === 'ollama';

            if (!isLocal || (this.config.apiKey && this.config.apiKey.trim() !== '')) {
                headers['Authorization'] = `Bearer ${this.config.apiKey}`;
            }

            // Route request through our Node.js server to bypass browser CORS restrictions
            const response = await fetch(`${BACKEND_URL}/proxy/llm`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    targetUrl: `${this.config.baseUrl}/chat/completions`,
                    headers: headers,
                    body: {
                        model: this.config.model || 'local-model',
                        messages: conversation,
                        stream: false
                    }
                })
            });

            if (!response.ok) {
                const errText = await response.text();
                throw new Error(`LLM API Error (${response.status}): ${errText}`);
            }

            const data = await response.json();
            const aiContent = data.choices?.[0]?.message?.content || '...';

            // 4. Log Assistant Response
            await this.logInteraction(sessionId, 'assistant', aiContent);

            return aiContent;

        } catch (err) {
            console.error('LLM Error', err);
            return "Error: Could not connect to AI patient. Please check settings.";
        }
    },

    async logInteraction(sessionId, role, content) {
        if (!sessionId) return;
        try {
            await fetch(`${BACKEND_URL}/interactions`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ session_id: sessionId, role, content })
            });
        } catch (e) {
            console.error('Logging failed', e);
        }
    }
};
